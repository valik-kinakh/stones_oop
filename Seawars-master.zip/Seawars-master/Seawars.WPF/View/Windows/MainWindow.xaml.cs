﻿using System.Windows;

namespace Seawars.WPF.View.Windows
{
    public partial class AuthorizationWindow : Window
    {
        public AuthorizationWindow() => InitializeComponent();
    }
}
