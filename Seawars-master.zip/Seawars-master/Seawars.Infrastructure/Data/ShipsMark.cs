﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seawars.Infrastructure.Data
{
    public static class ShipsMark
    {
        public const string DeadShip = "X";
        public const string Ship = "O";
        public const string Missed = " ";

    }
}
