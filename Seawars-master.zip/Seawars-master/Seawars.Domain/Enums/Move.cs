﻿namespace Seawars.Domain.Enums
{
    public enum Move
    {
        Enimy = 1,
        Your = 2,
    }
}