﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Seawars.Domain.Enums
{
    public enum Fields
    {
        NativeField = 1,
        EnemyField = 2,
    }
}
