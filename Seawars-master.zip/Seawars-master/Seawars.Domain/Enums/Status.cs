﻿namespace Seawars.Domain.Enums
{
    public enum Status
    {
        Win = 1,
        Loose = 2,
        Undefined = 3
    }
}